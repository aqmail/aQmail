#include "dns_qmail.h"

int ip4_scan(const char *s,char ip[4]) {
  return ip_scan(s,ip);
}
