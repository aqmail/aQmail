#include "dns_qmail.h"
#include "error.h"

int dns_doe() {
  if (errno == error_proto) return DNS_HARD;
  if (errno == error_nomem) return DNS_MEM;
  return DNS_SOFT;
}
