#include "dns_qmail.h"
#include "byte.h"

int dns_cname_resolve = 1;

int dns_cname(stralloc *sa) {
  int loop, r;
  char *s;

  for (loop = 0;loop < 10;++loop) {
    if (!sa->len) return loop;
    if (sa->s[sa->len - 1] == ']') return loop;
    if (sa->s[sa->len - 1] == '.') { --sa->len; continue; }

    if (dns_cname_resolve == 0) return loop;
    if (dns_qmail_resolve(dns_qmail_tmp_out, sa, DNS_T_CNAME) == -1) {
      if ((r = dns_doe()) == DNS_HARD) return loop;
      return r;
    }

    if ((r = dns_qmail_tmp_out->len) <= 0) return loop;
    s = dns_qmail_tmp_out->s;
    if (dns_resolve_all_names) r = byte_chr(s,r,0);
    if (!stralloc_copyb(sa,s,r)) return DNS_MEM;
  }
  return DNS_HARD; /* alias loop */
}
