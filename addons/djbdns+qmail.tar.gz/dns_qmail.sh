
#ifndef DNS_QMAIL_H
#define DNS_QMAIL_H

#define DNS_SOFT -1
#define DNS_HARD -2
#define DNS_MEM -3

extern unsigned int ip_scan();
extern unsigned int ip_scanbracket();

extern int dns_qmail_resolve(stralloc *,const stralloc *,const char tp[2]);
extern int dns_doe(void);
extern int dns_resolve_all_names;
extern int dns_cname_resolve;
extern int dns_qmail_compatible;
extern stralloc *dns_qmail_tmp_out;

extern int dns_cname(stralloc *);
extern int dns_ip(ipalloc *,stralloc *);
extern int dns_mxip(ipalloc *,stralloc *,unsigned long);
extern int dns_ptr(stralloc *sa, struct ip_address *ip);

/* added by NV to work easy with djbdns style */
extern int dns_txt(stralloc *, const stralloc *);
extern int dns_name4(stralloc *, const char ip[4]);

#define dns_ip4(o,f)	dns_qmail_resolve(o,f,DNS_T_A)
#define dns_ns(o,f)	dns_qmail_resolve(o,f,DNS_T_NS)
#define dns_mx(o,f)	dns_qmail_resolve(o,f,DNS_T_MX)

/* qmail have dns_cname(stralloc *) already in qmail-remote.c */
#define dns_cname4(o,f)  dns_qmail_resolve(o,f,DNS_T_CNAME)

#endif
