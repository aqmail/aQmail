#include "dns_qmail.h"

int dns_txt(stralloc *sa, const stralloc *fqdn) {

#ifndef QMAIL_STYLE_DNS_TXT
  return dns_qmail_resolve(sa, fqdn, DNS_T_TXT);
}

#else
  if (dns_qmail_resolve(sa, fqdn, DNS_T_TXT) == -1) return dns_doe();
  if (sa->len) return 0;
  return DNS_HARD;
}
#endif
