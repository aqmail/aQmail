#include "dns_qmail.h"

#include "stralloc.h"
#include "byte.h"
#include "dns.h"
#include "fmt.h"

int dns_name4(stralloc *sa, const char ip[4]) {
  char name[DNS_NAME4_DOMAIN], *p=name;
  stralloc fqdn = { name, 0, DNS_NAME4_DOMAIN };
  int k;

  for (k=3; k>=0; k--) {
    p += fmt_ulong(p, (unsigned long)(unsigned char)ip[k]);
    *p++ = '.';
  }

  byte_copy(p,12,"in-addr.arpa");
  fqdn.len = p-name + 12;
  return dns_qmail_resolve(sa, &fqdn, DNS_T_PTR);
}
