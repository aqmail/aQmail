#include "dns_qmail.h"
#include "byte.h"
#include "alloc.h"

static struct ip_mx ix;
static stralloc out = {0};
stralloc *dns_qmail_tmp_out = &out;
int dns_qmail_compatible = 0;

static int newix_append(ipalloc *ia, struct ip_mx *n) {
  unsigned int k = ia->len;
  if (dns_qmail_compatible == 0)
    while (k)
      if (!byte_diff(ia->ix[--k].ip.d , 4, n->ip.d)) return 1;
  return ipalloc_append(ia,n);
}

static int test_brackets(ipalloc *ia, stralloc *sa) {
  if (!stralloc_copy(&out, sa)) return DNS_MEM;
  if (!stralloc_0(&out)) return DNS_MEM;
  if (out.s[0])
    if (!out.s[ip_scan(out.s,&ix.ip)] ||
	!out.s[ip_scanbracket(out.s,&ix.ip)]) {
      ix.pref = 0;
      if (!newix_append(ia,&ix)) return DNS_MEM;
      return 0;
    }
  return 1;
}

static int dns_ipplus(ipalloc *ia, stralloc *sa, int pref) {
  int j;
  char *s;
  if ((j = (test_brackets(ia,sa))) <= 0) return j;

  if (dns_qmail_resolve(&out, sa, DNS_T_A) == -1) return dns_doe();
  if (out.len < 4) return DNS_HARD;

  for (ix.pref=pref, s=out.s; 4<=out.len; out.len-=4, s+=4) {
    byte_copy(&ix.ip, 4, s);
    if (!newix_append(ia,&ix)) return DNS_MEM;
  }
  return (0);
}

int dns_ip(ipalloc *ia, stralloc *sa) {
  if (!ipalloc_readyplus(ia,0)) return DNS_MEM;
  ia->len = 0;
  return dns_ipplus(ia,sa,0);
}

int dns_mxip(ipalloc *ia, stralloc *sa, unsigned long u) {
  int i, j, nummx;
  int flagsoft = 0;
  struct mx { stralloc sa; unsigned short p; } *mx;

  if (!ipalloc_readyplus(ia,0)) return DNS_MEM;
  ia->len = 0;
  if ((j = (test_brackets(ia,sa))) <= 0) return j;

  dns_random((unsigned int)u);
  if (dns_qmail_resolve(&out,sa,DNS_T_MX) == -1) { return dns_doe(); }
  else if (!out.len) return (dns_ip(ia,sa));

  i=2; nummx=0;
  while (i < out.len)
    if (out.s[i] == '\0') { nummx++; i += 3; }
    else i++;

  mx = (struct mx *) alloc(nummx * sizeof(struct mx));
  if (!mx) return DNS_MEM;

  i=0;j=0;
  while (j < nummx) {
    mx[j].p =  256*(unsigned char)out.s[i] + (unsigned char)out.s[i+1];
    mx[j].sa.s = 0;
    if (!stralloc_copys(&mx[j].sa, out.s+i+2)) {
      while (j > 0) alloc_free(mx[--j].sa.s);
      alloc_free(mx); return DNS_MEM;
    }
    i += 3 + mx[j++].sa.len;
  }

  while (nummx > 0)  {
    for (i=0,j= 1;j < nummx;++j)
      if (mx[j].p < mx[i].p) i = j;

    switch (dns_ipplus(ia,&mx[i].sa ,mx[i].p)) {
      case DNS_MEM: case DNS_SOFT:  flagsoft = 1; break;
    }

    alloc_free(mx[i].sa.s);
    mx[i] = mx[--nummx];
  }

  alloc_free(mx);
  return flagsoft;
}
