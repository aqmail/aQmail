void dns_init(int u) {}
