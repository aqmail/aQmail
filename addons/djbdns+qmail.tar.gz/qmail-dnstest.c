/* qmail-dnstest.c */
/* this program test dns_ip, dns_mxip, dns_cname functions for qmail */

#include <sys/time.h>
#include <unistd.h>
#include "error.h"
#include "fmt.h"
#include "ip4.h"
#include "dns_qmail.h"
#include "buffer.h"

char buf[256];

void print_doe(int k, stralloc *sa) {
  int e=0;
  char *p=buf;
  if (k==-1) e = dns_doe();
  else if (k==0 && sa->len==0) e = DNS_HARD; 
  buffer_puts(buffer_1, "\nexit status: ");
  if (e<0) { *p++ = '-'; e = -e; }
  p += fmt_ulong(p,e);
  buffer_put(buffer_1, buf, p-buf);
}

void print_time () {
  unsigned long u=0;
  unsigned long r;
  struct timeval tv;
  gettimeofday(&tv,0);
  u += fmt_ulong(buf+u, tv.tv_sec); buf[u++] = '.';
  for (r=0; r<6; r++) buf[u+r] = '0';
  r = fmt_ulong(buf+u+10, tv.tv_usec);
  if (r<6) u += 6-r; 
  u += fmt_ulong(buf+u , tv.tv_usec); buf[u++] = ';'; buf[u++] = ' ';
  buffer_put(buffer_1,buf,u);
}

void print_status (const char *s, int r, unsigned long u) {
  unsigned long q=0;
  print_time();
  buffer_puts(buffer_1, s);
  if (r<0) {r= -r; buf[q++] = '-';}
  q += fmt_ulong(buf+q, r);
  buffer_put(buffer_1,buf,q);
  
  buffer_puts(buffer_1, "; allocated IP numbers: ");
  q = fmt_ulong(buf, u); buf[q++] = '\n';
  buffer_put(buffer_1,buf,q);
  buffer_flush(buffer_1);
}

ipalloc ia = {0};

void print_ia() {
  unsigned long q,k;

  for (k=0; k< ia.len; k++) {
    q = fmt_ulong(buf, ia.ix[k].pref);
    buf[q++] = '\t';
    q += ip4_fmt(buf+q, (unsigned char *)&ia.ix[k].ip);
    buf[q++] = '\n';
    buffer_put(buffer_1, buf, q);
  }
}

void mem () {write (1, "no memory\n", 10); _exit(100);}

int main(int argc, char **argv) {
  stralloc sa = {0};
  stralloc fqdn = {0};
  int r;
  unsigned long q=0;

  if (argc<2) {
    buffer_puts(buffer_1, "usage: qmail-dnstest [dom] [-cdom] [-mdom] [-ndom] [-pdom] [-tdom] ... \n");
    buffer_flush(buffer_1);
    _exit(100);
  }
  ++argv;

  if (!ipalloc_readyplus(&ia,"") == -1) mem();
  fmt_ulong(buf, getpid());   fmt_ulong(buf+10, getppid());
  dns_random_init(buf);
  
  while (*argv) {
    if (argv[0][0] == '-') {
      char *x=argv[0]+1;
      char ip[4];
      int k,e;
      
      if (!stralloc_copys(&fqdn, x+1)) mem();
      dns_resolve_all_names = 1;

      print_time();
      switch (*x) {
      case 't':	buffer_puts(buffer_1, "(TXT) "); break;
      case 'n':	buffer_puts(buffer_1, "(NS) "); break;
      case 'c':	buffer_puts(buffer_1, "(CNAME) "); break;
      case 'p':	buffer_puts(buffer_1, "(PTR) "); break;
      case 'm':	buffer_puts(buffer_1, "(MX) "); break;
      default:
	buffer_puts(buffer_1, "wrong option: ");
	buffer_put(buffer_1,x-1,2);
      }
      
      buffer_puts(buffer_1, x+1);
      buffer_puts(buffer_1, " =\n");
      
      switch (*x) {
      case 'n':	k=dns_ns(&sa, &fqdn); e=k; break;
      case 'c':	k=dns_cname4(&sa, &fqdn); e=k; break;
      case 'm': 
	k=dns_mx(&sa, &fqdn); e=k;
	print_time();
	if (k==0 && sa.len) {
	  char *a = sa.s, *b = sa.s + sa.len;
	  while (a+2 < b) {
	    buffer_puts(buffer_1,"\n");
	    q=fmt_ulong(buf,((unsigned char)a[0]<<8) +(unsigned char)a[1]);
	    buf[q++] = '\t';
	    buffer_put(buffer_1, buf, q);
	    buffer_puts(buffer_1, a+2);
	    a += strlen(a+2) + 3;
	  }
	}
	k=-1;
	break;
      case 't': 
	k=dns_txt(&sa, &fqdn); e=k;
	break;
      case 'p':	
	if (!ip4_scan(x+1,ip)) { k=-1; e=-1; errno=error_proto; break; }
	k=dns_name4(&sa, ip); e=k;
	break;
      default:
	k = -1;
	e = 0;
      }
      
      if (k==0 && sa.len) {
      }

      if (k==0 && sa.len) {
	char *a,*b;
	print_time();
	if (!stralloc_readyplus(&sa,1)) mem();
	sa.s[sa.len] = 0;
	a = sa.s, b = sa.s + sa.len;	

	while(*a && a < b) {
	  buffer_puts(buffer_1, a);
	  a += strlen(a) + 1;
	  if (a<b) buffer_puts(buffer_1, " ");
	}
      }
      print_doe(e, &sa);
      buffer_puts(buffer_1, "\n\n");
      buffer_flush(buffer_1);
      ++argv;
      continue;
    }
    dns_resolve_all_names = 0;

    /* --------- qmail dns_ip and qns_mxip ------- */
    dns_qmail_compatible = 1;
    buffer_puts(buffer_1,"  dns_qmail_compatible = 1\n");

  again:
    ia.len = 0;
    if (!stralloc_copys(&sa, *argv)) mem();

    print_time();
    buffer_puts(buffer_1, *argv);    
    buffer_puts(buffer_1, "\n");
    buffer_flush(buffer_1);
    
    /* -------------------------------------- */
    r = dns_ip(&ia, &sa); 
    print_ia();
    print_status("exit status of dns_ip: ", r, ia.len);
    /* -------------------------------------- */
    ia.len=0;
    r = dns_mxip(&ia, &sa, 0);
    print_ia();
    print_status("exit status of dns_mxip: ", r, ia.len);
    /* -------------------------------------- */
    r = dns_cname(&sa);
    
    print_time();
    buffer_puts(buffer_1, "exit status of dns_cname: ");
    q=0; if (r<0) {r= -r; buf[q++] = '-';}
    q += fmt_ulong(buf+q, r);
    buffer_put(buffer_1, buf,q);
    buffer_puts(buffer_1, "; canonical name: ");
    buffer_put(buffer_1, sa.s, sa.len);
    buffer_puts(buffer_1, "\n\n");
    buffer_flush(buffer_1);

    if (dns_qmail_compatible) {
      dns_qmail_compatible = 0;
      buffer_puts(buffer_1,"  dns_qmail_compatible = 0\n");
      goto again; 
    }
    argv++;
  }
  return(0);
}
