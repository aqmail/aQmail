#include <errno.h>
#include "error.h"
#include "stralloc.h"
#include "uint16.h"
#include "byte.h"
#include "dns.h"

static char *q = 0;

/* if nonzero resolve all names for NS, CNAME, PTR records */
/* in djbdns it is zero for CNAME and PTR */
int dns_resolve_all_names = 0;

static int dns_qmail_packet(stralloc *out,const char *buf,unsigned int len,char type[2])
{
  unsigned int pos;
  char header[12];
  char pref[2];
  uint16 numanswers;
  uint16 datalen;

  if (!stralloc_copys(out,"")) return -1;

  pos = dns_packet_copy(buf,len,0,header,12); if (!pos) return -1;
  uint16_unpack_big(header + 6,&numanswers);
  pos = dns_packet_skipname(buf,len,pos); if (!pos) return -1;
  pos += 4;

  while (numanswers--) {
    pos = dns_packet_skipname(buf,len,pos); if (!pos) return -1;
    pos = dns_packet_copy(buf,len,pos,header,10); if (!pos) return -1;
    uint16_unpack_big(header + 8,&datalen);
    if (byte_equal(header,2,type))
      if (byte_equal(header + 2,2,DNS_C_IN))
        switch (type[1]) {
	case '\1':  /* A */
	  if (datalen == 4) {
	    if (!dns_packet_copy(buf,len,pos,header,4)) return -1;
	    if (!stralloc_catb(out,header,4)) return -1;
	  }
	  break;
	case '\17': /* MX */
	  if (!dns_packet_copy(buf,len,pos,pref,2)) return -1;
	  if (!dns_packet_getname(buf,len,pos + 2,&q)) return -1;
	  if (!stralloc_catb(out,pref,2)) return -1;
	  goto append;
	case '\2':  /* NS    */
	case '\5':  /* CNAME */
	case '\14': /* PTR   */
	  if (!dns_packet_getname(buf,len,pos,&q)) return -1;
	append:
	  if (!dns_domain_todot_cat(out,q)) return -1;
	  if (type[1] == '\17' || dns_resolve_all_names) {
	    if (!stralloc_0(out)) return -1;
	    break;
	  } else return 0;
#ifdef USE_DNS_TXT
	case '\20': /* TXT */
	  if (pos + datalen > len) { errno = error_proto; return -1; }
	  else {
	    char ch;
	    unsigned int txtlen=0;
	    int i;

	    for (i = 0;i < datalen;++i) {
	      ch = buf[pos + i];
	      if (!txtlen)
		txtlen = (unsigned char) ch;
	      else {
		--txtlen;
		if (ch < 32 || ch > 126) ch = '?';
		if (!stralloc_append(out,&ch)) return -1;
	      }
	    }
	  }
	  break;
#endif
	}
    pos += datalen;
  }
  return 0;
}

int dns_qmail_resolve(stralloc *out,const stralloc *fqdn,char type[2])
{
  if (!dns_domain_fromdot(&q,fqdn->s,fqdn->len)) return -1;
  if (dns_resolve(q,type) == -1) return -1;
  if (dns_qmail_packet(out,dns_resolve_tx.packet,dns_resolve_tx.packetlen,type) == -1) return -1;
  dns_transmit_free(&dns_resolve_tx);
  dns_domain_free(&q);
  return 0;
}
