#include "dns_qmail.h"

int dns_ptr(stralloc *sa, struct ip_address *ip) {
  if (dns_name4(sa, ip->d) == -1) return dns_doe();
  if (sa->len) return 0;
  return DNS_HARD;
}
